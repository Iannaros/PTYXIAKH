package Core;

import java.util.LinkedList;

import Core.Classroom;
import Core.CompositeState;
import Core.Equipment;
import Core.Office;

public abstract sealed class Room implements CompositeState permits Office, Classroom {
	
	public static final String CLASSROOM_TAB_NAME = "classroom";
	public static final String OFFICE_TAB_NAME 	  = "office";
	
	protected int dbid;
	protected String name;
	protected int floor;
	
	protected abstract LinkedList<Equipment> getComponents();
	
	Room(int id, String st, int f) {
		this.dbid = id;
		this.name = st;
		this.floor = f;
	}
	
	public abstract String getEquipmentPanelName();
	
	@Override
	public boolean totalIsOK() {
		return this.getComponents().stream().allMatch(Equipment::unitIsOK);
	}
	
	public int getDbid() {
		return dbid;
	}
	
	@Override
	public String toString() {
		return this.name;
	}
}
