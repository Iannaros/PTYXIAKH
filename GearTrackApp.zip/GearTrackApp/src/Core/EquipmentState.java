package Core;

public enum EquipmentState {
	  NOK(-1)	// = -1, Not installed or Missing
	, ERR(0)	// =  0, Installed but disfunctional
	, OK(1);	// =  1, Installed and working 
	
	private final int dbValue;
	
	EquipmentState(int x) {
		this.dbValue = x;
	}
	
	public int getDBValue() {
		return dbValue;
	}
}