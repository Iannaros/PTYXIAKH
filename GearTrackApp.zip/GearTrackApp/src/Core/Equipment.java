package Core;

import Core.EquipmentComposite;
import Core.EquipmentState;
import Core.HasState;
import Core.Monitor;
import Core.Phone;
import Core.Projector;
import Core.Speakers;
import Core.WebCam;

public sealed abstract class Equipment implements HasState permits   Phone, Speakers, WebCam, Monitor, Projector, EquipmentComposite
{
	protected int dbid;
	protected EquipmentState state = EquipmentState.OK;
	
	Equipment(int id, EquipmentState st) {
		this.dbid = id;
		this.state = st;
	}
	
	Equipment(int id) {
		this.dbid = id;
	}
	Equipment(Integer id) {
		this.dbid = id;
	}

	public int getDbid() {
		return dbid;
	}
	
	public EquipmentState getState() {
		return this.state;
	}
	
	public void setState(EquipmentState st) {
		this.state = st;
	}
	
	@Override
	public boolean unitIsOK() {
		return this.state == EquipmentState.OK;
	}
	
}