package Core;

import Core.Equipment;
import Core.EquipmentState;

public final class Phone extends Equipment {
	
	private String lineNumber;

	public Phone(int id, EquipmentState st) {
		super(id, st);
	}

	public Phone(int id, String line) {
		super(id);
		this.lineNumber = line;
	}

	public Phone(Integer id, String line) {
		super(id);
		this.lineNumber = line;
	}

	public Phone(Integer id) {
		super(id);
	}

	public String getLineNumber() {
		return this.lineNumber;
	}
	
	public void setLineNumber(String str) {
		this.lineNumber = str;
	}

	
	
	
}