package Core;

public interface HasState {
	boolean unitIsOK();
}
