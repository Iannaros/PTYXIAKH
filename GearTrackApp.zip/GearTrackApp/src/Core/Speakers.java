package Core;

import Core.Equipment;
import Core.EquipmentState;

public final class Speakers extends Equipment {
	public Speakers(int id) {
		super(id);
	}
	
	public Speakers(int id, EquipmentState st) {
		super(id, st);
	}

	public Speakers(Integer id) {
		super(id);
	}
}
