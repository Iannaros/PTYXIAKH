package Core;

import Core.Equipment;
import Core.EquipmentState;

public final class WebCam extends Equipment {
	
	public WebCam(Integer id) {
		super(id);
	}
	
	public WebCam(int id, EquipmentState st) {
		super(id, st);
	}

}
