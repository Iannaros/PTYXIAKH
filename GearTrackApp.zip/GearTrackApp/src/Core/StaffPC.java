package Core;

import java.util.LinkedList;
import java.util.stream.Stream;

public final class StaffPC extends StudentPC {
	private WebCam camera;
	private Speakers speakers;
	
	public StaffPC(int id) {
		super(id);
	}
	
//	public StaffPC(int id, Monitor m) {
//		super(id, m);
//	}
	
	public StaffPC(int id, Monitor m, WebCam wc, Speakers sp) {
		super(id, m);
		this.camera = wc;
		this.speakers = sp;
	}
	
	public StaffPC(int id, EquipmentState st) {
		super(id, st);
	}
	
	@Override
	public LinkedList<Equipment> getComponents() {
		LinkedList<Equipment> result = super.getComponents();
		result.add(camera);
		result.add(speakers);
		return result;
	}

	public WebCam getCamera() {
		return camera;
	}

	public Speakers getSpeakers() {
		return speakers;
	}
	
	
}
