package Core;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.stream.Stream;

public final class Classroom extends Room {
	
	private Projector projector;
	private StaffPC teacherPC;
	private HashMap<Integer, StudentPC> studentPCs = new HashMap<Integer, StudentPC>();
	
	public Classroom(int id, String name, int floor) {
		super(id, name, floor);
	}
	
	public Classroom(int id, String name, int floor, Projector p, StaffPC pc, Collection<StudentPC> list) {
		this(id, name, floor);
		this.projector = p;
		this.teacherPC = pc;
		list.forEach(this::addStudentPC);
	}
	
	public void addStudentPC(StudentPC pc) {
		this.studentPCs.put(pc.dbid, pc);
	}

	public Collection<StudentPC> getStudentPCs() {
		return studentPCs.values();
	}
	
	@Override
	public String getEquipmentPanelName() {
		return Room.CLASSROOM_TAB_NAME;
	}
	
	@Override
	protected LinkedList<Equipment> getComponents() {
		LinkedList<Equipment> result = new LinkedList<Equipment>();
		result.add(projector);
		result.add(teacherPC);
		result.addAll(studentPCs.values());
		return result;
	}
}
