package Core;

import Core.Equipment;
import Core.EquipmentState;

public final class Monitor extends Equipment {

	public Monitor(Integer id) {
		super(id);
	}
	
	public Monitor(int id, EquipmentState st) {
		super(id, st);
	}
}
