package Core;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.stream.Stream;

public final class Office extends Room {
	
	HashMap<Integer, Phone>   phones	= new HashMap<Integer, Phone>();
	HashMap<Integer, StaffPC> computers = new HashMap<Integer, StaffPC>();

	public Office(int id, String st, int floor, Collection<StaffPC> list, Collection<Phone> phs) {
		super(id, st, floor);
		list.stream().forEach(this::addStaffPC);
		phs.stream().forEach(this::addPhone);
	}
	
	public void addStaffPC(StaffPC pc) {
		this.computers.put(pc.dbid, pc);
	}
	
	public void addPhone(Phone ph) {
		this.phones.put(ph.dbid, ph);
	}
	
	@Override
	protected LinkedList<Equipment> getComponents() {
		return new LinkedList<Equipment>(computers.values());
	}

	public Collection<Phone> getPhones() {
		return phones.values();
	}

	public Collection<StaffPC> getComputers() {
		return computers.values();
	}

	@Override
	public String getEquipmentPanelName() {
		return Room.OFFICE_TAB_NAME;
	}
	
	
}
