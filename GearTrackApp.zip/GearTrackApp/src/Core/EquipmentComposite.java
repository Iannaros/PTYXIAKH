package Core;

import java.util.LinkedList;

import Core.CompositeState;
import Core.Equipment;
import Core.EquipmentState;
import Core.StudentPC;

public abstract sealed class EquipmentComposite extends Equipment implements CompositeState permits StudentPC {
	
	protected abstract LinkedList<Equipment> getComponents();

	public EquipmentComposite(int id, EquipmentState st) {
		super(id, st);
	}

	public EquipmentComposite(int id) {
		super(id);
	}

	public EquipmentComposite(Integer id) {
		super(id);
	}
	
	@Override
	public boolean totalIsOK() {
		return this.unitIsOK() && this.getComponents().stream().allMatch(Equipment::unitIsOK);
	}
}
