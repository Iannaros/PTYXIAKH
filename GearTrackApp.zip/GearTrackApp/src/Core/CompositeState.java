package Core;

public interface CompositeState {

	boolean totalIsOK();
}
