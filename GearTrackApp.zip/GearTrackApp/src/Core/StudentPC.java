package Core;

import java.util.LinkedList;

public sealed class StudentPC extends EquipmentComposite permits StaffPC {
	
	protected Monitor monitor;
	
	public StudentPC(int id) {
		super(id);
	}
	
	public StudentPC(int id, Monitor m) {
		super(id);
		this.monitor = m;
	}
	
	public StudentPC(int id, EquipmentState st) {
		super(id, st);
	}
	@Override
	protected LinkedList<Equipment> getComponents() {
		LinkedList<Equipment> result = new LinkedList<Equipment>();
		result.add(monitor);
		return result;
	}
	
	@Override
	public String toString() {
		return Integer.valueOf(dbid).toString();
	}

	public Monitor getMonitor() {
		return monitor;
	}
	
	
}
