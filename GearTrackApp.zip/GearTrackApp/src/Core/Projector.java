package Core;

import Core.Equipment;
import Core.EquipmentState;

public final class Projector extends Equipment {

	public Projector(int id, EquipmentState st) {
		super(id, st);
	}

	public Projector(int id) {
		super(id);
	}

	public Projector(Integer id) {
		super(id);
	}
}
