package View_Dashboard;

import javax.swing.JPanel;
import javax.swing.ListCellRenderer;
import javax.swing.plaf.basic.BasicComboBoxRenderer;

import Core.Phone;
import Core.StaffPC;
import Core.StudentPC;

import javax.swing.BoxLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.util.Collection;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JList;

import java.awt.Font;
import javax.swing.JComboBox;
import java.awt.BorderLayout;
import java.awt.Component;
import javax.swing.border.EmptyBorder;

public class ChooseOfficePanel extends ChooseRoomPanel {
	
	JComboBox<Phone> cbPhone;
	JComboBox<StaffPC> cbStaffPC;

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public ChooseOfficePanel() {
		setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		
		JPanel panel_3 = new JPanel();
		add(panel_3);
		panel_3.setLayout(new BoxLayout(panel_3, BoxLayout.Y_AXIS));
		
		JPanel pnlChooseStaffPC = new JPanel();
		EmptyBorder myBorder = new EmptyBorder(5, 0, 5, 0);
		pnlChooseStaffPC.setBorder(myBorder);
		panel_3.add(pnlChooseStaffPC);
		pnlChooseStaffPC.setLayout(new GridLayout(0, 1, 0, 0));
		
		JPanel panel_5 = new JPanel();
		pnlChooseStaffPC.add(panel_5);
		panel_5.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 5));
		
		JLabel lblPC = new JLabel("H/Y");
		lblPC.setFont(new Font("Dialog", Font.BOLD, 14));
		panel_5.add(lblPC);
		
		cbStaffPC = new JComboBox<StaffPC>();
		cbStaffPC.setFont(new Font("Dialog", Font.BOLD, 14));
		pnlChooseStaffPC.add(cbStaffPC);
		
		JPanel pnlChoosePhone = new JPanel();
		pnlChoosePhone.setBorder(myBorder);
		panel_3.add(pnlChoosePhone);
		pnlChoosePhone.setLayout(new GridLayout(0, 1, 0, 0));
		
		JPanel panel_5_1 = new JPanel();
		pnlChoosePhone.add(panel_5_1);
		panel_5_1.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 5));
		
		JLabel lblT = new JLabel("Τηλέφωνο");
		lblT.setFont(new Font("Dialog", Font.BOLD, 14));
		panel_5_1.add(lblT);
		
		cbPhone = new JComboBox<Phone>();
		cbPhone.setFont(new Font("Dialog", Font.BOLD, 14));
		pnlChoosePhone.add(cbPhone);
		cbPhone.setRenderer(new PhoneRenderer());
		
		JPanel pnlEmpty = new JPanel();
		panel_3.add(pnlEmpty);
		pnlEmpty.setLayout(new BorderLayout(0, 0));
	}
	
	public void setPhones(Collection<Phone> pcs) {
		cbPhone.removeAllItems();
		pcs.forEach(cbPhone::addItem);
	}
	
	public void setPCs(Collection<StaffPC> pcs) {
		cbStaffPC.removeAllItems();
		pcs.forEach(cbStaffPC::addItem);
	}
}

class PhoneRenderer extends JLabel implements ListCellRenderer<Phone> {
	private static final long serialVersionUID = 1L;
	private static BasicComboBoxRenderer defaultRenderer = new BasicComboBoxRenderer();

	@Override
	public Component getListCellRendererComponent(JList arg0, Phone arg1, int arg2, boolean arg3, boolean arg4) {
		if (arg1 == null)
			return new JLabel("");
		return defaultRenderer.getListCellRendererComponent(arg0, arg1.getLineNumber(), arg2, arg3, arg4);
	}
}