package View_Dashboard;

import javax.swing.JPanel;

import Core.StudentPC;

import java.awt.FlowLayout;
import javax.swing.BoxLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.util.Collection;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.border.EmptyBorder;

public class ChooseClassroomPanel extends ChooseRoomPanel {

	private static final long serialVersionUID = 1L;
	
	JComboBox<StudentPC> cbStudentPC;

	/**
	 * Create the panel.
	 */
	public ChooseClassroomPanel() {
		FlowLayout flowLayout = (FlowLayout) getLayout();
		flowLayout.setVgap(0);
		flowLayout.setHgap(0);
		flowLayout.setAlignment(FlowLayout.LEFT);
		
		JPanel panel_4 = new JPanel();
		add(panel_4);
		panel_4.setLayout(new BoxLayout(panel_4, BoxLayout.X_AXIS));
		
		JPanel pnlChooseStudentPC = new JPanel();
		pnlChooseStudentPC.setBorder(new EmptyBorder(5, 0, 5, 0));
		panel_4.add(pnlChooseStudentPC);
		pnlChooseStudentPC.setLayout(new GridLayout(0, 1, 0, 0));
		
		JPanel panel_5 = new JPanel();
		pnlChooseStudentPC.add(panel_5);
		panel_5.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 5));
		
		JLabel lblPC = new JLabel("H/Y");
		lblPC.setFont(new Font("Dialog", Font.BOLD, 14));
		panel_5.add(lblPC);
		
		cbStudentPC = new JComboBox<StudentPC>();
		cbStudentPC.setFont(new Font("Dialog", Font.BOLD, 14));
		pnlChooseStudentPC.add(cbStudentPC);

	}
	
	public void setData(Collection<StudentPC> pcs) {
		cbStudentPC.removeAllItems();
		pcs.forEach(cbStudentPC::addItem);
	}
}