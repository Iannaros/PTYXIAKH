package View_Dashboard;

import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import Controller_Dashboard.Controller_Dashboard;
import Core.Room;
import Core_Pool.Pool;

import javax.swing.BoxLayout;
import java.util.Collection;

import javax.swing.JLabel;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.border.EmptyBorder;

public class RoomNavigationPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	
	private JComboBox<Room> cbRooms;
	private CardLayout cardLayout;
	private JPanel pnlChooseRoomEquipment;
	private ActionListener roomSelectedListener;
	
	private RoomNavigationController controller;

	/**
	 * Create the panel.
	 */
	public RoomNavigationPanel() {
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setBorder(new TitledBorder(null, "\u03A0\u03BB\u03BF\u03AE\u03B3\u03B7\u03C3\u03B7", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new EmptyBorder(0, 5, 0, 5));
		add(panel_2);
		panel_2.setLayout(new BoxLayout(panel_2, BoxLayout.Y_AXIS));
		
		JPanel pnlChooseRoom = new JPanel();
		pnlChooseRoom.setBorder(null);
		panel_2.add(pnlChooseRoom);
		pnlChooseRoom.setLayout(new BoxLayout(pnlChooseRoom, BoxLayout.Y_AXIS));
		
		JPanel panel = new JPanel();
		FlowLayout flowLayout_1 = (FlowLayout) panel.getLayout();
		flowLayout_1.setAlignment(FlowLayout.LEFT);
		pnlChooseRoom.add(panel);
		
		JLabel lblRoom = new JLabel("Αίθουσα");
		lblRoom.setFont(new Font("Dialog", Font.BOLD, 14));
		panel.add(lblRoom);
		
		cbRooms = new JComboBox<Room>();
		cbRooms.setFont(new Font("Dialog", Font.BOLD, 14));
		pnlChooseRoom.add(cbRooms);
				
		pnlChooseRoomEquipment = new JPanel();
		panel_2.add(pnlChooseRoomEquipment);
		cardLayout = new CardLayout(0, 0);
		pnlChooseRoomEquipment.setLayout(cardLayout);
		
		ChooseOfficePanel pnlChooseOfficeEquipment = new ChooseOfficePanel();
		pnlChooseRoomEquipment.add(pnlChooseOfficeEquipment, "office");
		
		ChooseClassroomPanel pnlChooseClassroomEquipment = new ChooseClassroomPanel();
		pnlChooseRoomEquipment.add(pnlChooseClassroomEquipment, "classroom");
		
		this.controller = new RoomNavigationController(pnlChooseClassroomEquipment, pnlChooseOfficeEquipment);
		
		this.setRoomSelectedListener(e -> {
			Room selected = cbRooms.getItemAt(cbRooms.getSelectedIndex());
			String pnlName = controller.setCurrentRoomAndGetPanelNameFrom(selected);
			this.showRoomEquipmentPanel(pnlName);
		});
		

		this.addRooms(Pool.classrooms.values());
		this.addRooms(Pool.offices.values());
	}
	
	public void addRooms(Collection<? extends Room> rooms) {
		rooms.forEach(r -> this.cbRooms.addItem(r));
	}

	public void setRoomSelectedListener(ActionListener listener) {
		this.cbRooms.removeActionListener(this.roomSelectedListener);
		this.roomSelectedListener = listener;
		this.cbRooms.addActionListener(this.roomSelectedListener);
	}
	
	public void showRoomEquipmentPanel(String pnl_name) {
		this.cardLayout.show(this.pnlChooseRoomEquipment, pnl_name);
	}
}
