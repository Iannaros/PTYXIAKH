package View_Dashboard;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import Controller_Dashboard.Controller_Dashboard;
import View_Dashboard.OverviewPanel;
import View_Dashboard.RoomNavigationPanel;

public class DashboardPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public DashboardPanel() {
		setBorder(new EmptyBorder(5, 5, 5, 5));
		setLayout(new BorderLayout(0, 0));

		LineBorder myLineBorder = new LineBorder(new Color(139, 0, 139));
		Font myFont = new Font("Dialog", Font.BOLD, 14);
		
		JPanel pnlLeft = new JPanel();
		pnlLeft.setBorder(new EmptyBorder(5, 5, 5, 5));
		add(pnlLeft, BorderLayout.WEST);
		pnlLeft.setLayout(new BoxLayout(pnlLeft, BoxLayout.X_AXIS));
		RoomNavigationPanel pnlNavigation = new RoomNavigationPanel();
		pnlLeft.add(pnlNavigation);
		pnlNavigation.setBorder(new TitledBorder(new LineBorder(new Color(139, 0, 139)), "Navigation", TitledBorder.LEADING, TitledBorder.TOP, myFont, new Color(51, 51, 51)));
		
		JPanel pnlCenter = new JPanel();
		pnlCenter.setBorder(new EmptyBorder(5, 5, 5, 5));
		add(pnlCenter, BorderLayout.CENTER);
		pnlCenter.setLayout(new BoxLayout(pnlCenter, BoxLayout.X_AXIS));
		
		JPanel pnlOverview = new OverviewPanel();
		pnlCenter.add(pnlOverview);
		pnlOverview.setBorder(new TitledBorder(myLineBorder, "Overview", TitledBorder.LEADING, TitledBorder.TOP, myFont, null));
		
		new Controller_Dashboard(pnlNavigation);
	}

}
