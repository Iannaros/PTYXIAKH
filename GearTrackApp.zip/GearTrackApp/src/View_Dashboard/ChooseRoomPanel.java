package View_Dashboard;

import javax.swing.JPanel;

public class ChooseRoomPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public ChooseRoomPanel() {

	}

}
