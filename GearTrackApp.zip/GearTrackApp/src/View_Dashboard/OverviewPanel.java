package View_Dashboard;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class OverviewPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public OverviewPanel() {
		
		JLabel lblNewLabel = new JLabel("Label");
		add(lblNewLabel);
		
		textField = new JTextField();
		add(textField);
		textField.setColumns(10);

	}

}
