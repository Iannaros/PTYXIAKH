package View;

import java.awt.EventQueue;
import java.util.Collection;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Core.Room;
import View_Dashboard.DashboardPanel;
import View_Tickets.TicketsPanel;

import java.awt.BorderLayout;
import javax.swing.JTabbedPane;
import java.awt.Font;

public class EquipmentManagementWindow extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	public EquipmentManagementWindow() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 528, 379);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setFont(new Font("Dialog", Font.BOLD, 14));
		contentPane.add(tabbedPane, BorderLayout.CENTER);
		
		JPanel pnlDashboard = new DashboardPanel();
		tabbedPane.addTab("Dashboard", null, pnlDashboard, "Navigate to your institution's infrastructure.");
		
		JPanel pnlTickets = new TicketsPanel();
		tabbedPane.addTab("All Tickets", null, pnlTickets, null);
	}

}
