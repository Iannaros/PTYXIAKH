package Controller_Dashboard;

import javax.swing.tree.DefaultMutableTreeNode;

import Core.*;

public class TreeModelBuilder {
	
	public static DefaultMutableTreeNode makeTreeNode(Phone x) {
		return new DefaultMutableTreeNode(x, false);
	}
	
	public static DefaultMutableTreeNode makeTreeNode(Monitor x) {
		return new DefaultMutableTreeNode(x, false);
	}
	
	public static DefaultMutableTreeNode makeTreeNode(WebCam x) {
		return new DefaultMutableTreeNode(x, false);
	}
	
	public static DefaultMutableTreeNode makeTreeNode(Speakers x) {
		return new DefaultMutableTreeNode(x, false);
	}
	
	public static DefaultMutableTreeNode makeTreeNode(Projector x) {
		return new DefaultMutableTreeNode(x, false);
	}
	
	public static DefaultMutableTreeNode makeTreeNode(StudentPC x) {
		DefaultMutableTreeNode pcNode = new DefaultMutableTreeNode(x);
		if (x.getMonitor() != null) {
			DefaultMutableTreeNode monitorNode = makeTreeNode(x.getMonitor());
			pcNode.add(monitorNode);
		}
		return pcNode;
	}
	
	public static DefaultMutableTreeNode makeTreeNode(StaffPC x) {
		DefaultMutableTreeNode pcNode = new DefaultMutableTreeNode((StudentPC)x);
		DefaultMutableTreeNode childNode;
		if (x.getSpeakers() != null) {
			childNode = makeTreeNode(x.getMonitor());
			pcNode.add(childNode);
		}
		if (x.getCamera() != null) {
			childNode = makeTreeNode(x.getMonitor());
			pcNode.add(childNode);
		}
		return pcNode;
	}
}