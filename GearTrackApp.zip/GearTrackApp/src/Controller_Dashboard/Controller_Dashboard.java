package Controller_Dashboard;

import View_Dashboard.RoomNavigationPanel;

public class Controller_Dashboard {
	
	private final RoomNavigationPanel navigatorView;

	public Controller_Dashboard(RoomNavigationPanel navigatorView) {
		this.navigatorView = navigatorView;
	}
	
}
