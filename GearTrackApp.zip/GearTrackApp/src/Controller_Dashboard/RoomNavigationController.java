package Controller_Dashboard;

import javax.swing.JPanel;
import javax.swing.tree.DefaultTreeSelectionModel;

import Core.Classroom;
import Core.Office;
import Core.Room;
import Core_Pool.Pool;
import View_Dashboard.ChooseClassroomPanel;
import View_Dashboard.ChooseOfficePanel;
import View_Dashboard.ChooseRoomPanel;

public class RoomNavigationController {
	
	private Room currentRoom;
	private ChooseClassroomPanel classroomTab;
	private ChooseOfficePanel	  officeTab;
	
	public RoomNavigationController(ChooseClassroomPanel one, ChooseOfficePanel two) {
		this.classroomTab = one;
		this.officeTab = two; 
	}
	
	public Room getCurrentRoom() {
		return currentRoom;
	}
	
	
	public String setCurrentRoomAndGetPanelNameFrom(Room r) {
		this.setCurrentRoom(r);
		return currentRoom.getEquipmentPanelName();
	}
	
	public void setCurrentRoom(Room r) {
		this.currentRoom = r;
		if (currentRoom instanceof Classroom c) {
			classroomTab.setData(c.getStudentPCs());
		} else if (currentRoom instanceof Office c) {
			officeTab.setPhones(c.getPhones());
			officeTab.setPCs(c.getComputers());
		}
	}
}