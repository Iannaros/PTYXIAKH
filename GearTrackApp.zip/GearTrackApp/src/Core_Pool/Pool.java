package Core_Pool;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.stream.IntStream;

import Core.*;

public class Pool {

	public static ArrayList<Monitor>   monitors   = new ArrayList<Monitor>();
	public static ArrayList<WebCam>    webcams    = new ArrayList<WebCam>();
	public static ArrayList<Speakers>  speakers   = new ArrayList<Speakers>();
	public static ArrayList<Projector> projectors = new ArrayList<Projector>();
	public static ArrayList<Phone> 	   phones  	  = new ArrayList<Phone>(); 
	
	private static <T extends Equipment> void fillInEquipment(ArrayList<T> list, int count, Class<T> elementType) {

		if (!list.isEmpty()) {
			System.out.println("Equipment list not empty. Aborting arbitrary initialization.");
			return;
		}
		
		try {
		Constructor<T> constr = elementType.getConstructor(Class.forName("java.lang.Integer"));
		IntStream.range(0, count)
			.mapToObj( i -> {
				try {
					return constr.newInstance(Integer.valueOf(i));
				} catch(Exception e) {
					e.printStackTrace();
					return null;
				}
			})
			.forEach(list::add);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	static {
		final int MONITORS_COUNT = 10;
		Class<Monitor> monitorClass = (Class<Monitor>)(new Monitor(0).getClass()); 
		fillInEquipment(monitors, MONITORS_COUNT, monitorClass);

		final int WEBCAMS_COUNT = 5;
		Class<WebCam> webcamClass = (Class<WebCam>)(new WebCam(0).getClass());
		fillInEquipment(webcams, WEBCAMS_COUNT, webcamClass);

		final int SPEAKERS_COUNT = 5;
		Class<Speakers> speakerClass = (Class<Speakers>)(new Speakers(0).getClass());
		fillInEquipment(speakers, SPEAKERS_COUNT, speakerClass);
		
		final int PROJECTORS_COUNT = 5;
		Class<Projector> projectorClass = (Class<Projector>)(new Projector(0).getClass());
		fillInEquipment(projectors, PROJECTORS_COUNT, projectorClass);
		
		final int PHONES_COUNT = 5;
		Class<Phone> phoneClass = (Class<Phone>)(new Phone(0).getClass());
		fillInEquipment(phones, PHONES_COUNT, phoneClass);
		phones.stream().forEach(phone -> phone.setLineNumber("32" + phone.getDbid()));
	}

	public static HashMap<Integer, StudentPC> studentPCs = new HashMap<Integer, StudentPC>();
	public static ArrayList<StaffPC>   staffPCs   = new ArrayList<StaffPC>();
	public static HashMap<Integer, Classroom> classrooms = new HashMap<Integer, Classroom>();
	public static HashMap<Integer, Office>    offices 	 = new HashMap<Integer, Office>();
		
	static {

		LinkedList<Monitor>	  monitorsAux	= new LinkedList<Monitor>(monitors);
		LinkedList<WebCam>	  webcamsAux	= new LinkedList<WebCam>(webcams);
		LinkedList<Speakers>  speakersAux	= new LinkedList<Speakers>(speakers);
		LinkedList<Projector> projectorsAux = new LinkedList<Projector>(projectors);
		LinkedList<Phone> 	  phonesAux 	= new LinkedList<Phone>(phones);
		
		final int STUDENT_PCS_COUNT = 6;
		IntStream.range(0, STUDENT_PCS_COUNT)
			.mapToObj(i -> new StudentPC(i, monitorsAux.remove()))
			.forEach(pc -> studentPCs.put(pc.getDbid(), pc));
		
		final int STAFF_PCS_COUNT = 3;
		IntStream.range(0, STAFF_PCS_COUNT)
			.mapToObj(i -> new StaffPC(i, monitorsAux.remove(), webcamsAux.remove(), speakersAux.remove()))
			.forEach(staffPCs::add);
		
		LinkedList<StudentPC> studentPCsAux = new LinkedList<StudentPC>(studentPCs.values());
		LinkedList<StaffPC>   staffPCsAux   = new LinkedList<StaffPC>(staffPCs);
		
		
		final int CLASSROOMS_COUNT = 2;
		final int[] STUDENT_PC_PER_CLASSROOM = new int[] {2, 4};
		IntStream.range(0, STUDENT_PC_PER_CLASSROOM.length)
			.forEach(i -> {
				Classroom r = new Classroom(i, "Classroom "+i, i/2);
				IntStream.range(0, STUDENT_PC_PER_CLASSROOM[i])
					.forEach(count -> r.addStudentPC(studentPCsAux.remove()));
				classrooms.put(i, r);
			});
		
		final int OFFICES_COUNT = 1;
		IntStream.range(0, OFFICES_COUNT)
			.mapToObj(i -> new Office(i, "Office "+i, i/2, staffPCsAux, phonesAux))
			.forEach(c -> offices.put(c.getDbid(), c));
	}
	
	public static ArrayList<Room>   rooms   = new ArrayList<Room>();
	
	static {
		classrooms.forEach(rooms::add);
		offices.forEach(rooms::add);
	}
}
